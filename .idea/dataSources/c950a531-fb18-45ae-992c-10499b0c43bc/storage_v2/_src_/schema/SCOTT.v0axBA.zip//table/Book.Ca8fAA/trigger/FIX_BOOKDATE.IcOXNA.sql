create trigger FIX_BOOKDATE
  before insert
  on "Book"
  for each row
begin
    if :new."countPeople" = -1 then
        :new."isOverFive":=1;
    end if;
    dbms_output.put_line('Change isOverFive: '||:new."isOverFive");
end;
/


create trigger STOREPRODUCT
  after insert
  on LWN_PUTIN_STORAGE
  for each row
  when (new.ORDERNO is not null)
declare
    proNo SCOTT.LWN_PRODUCT.PRODUCTNO%type ;
		proCount int;
	begin
		select Qty into proCount from lwn_Procurement_detial WHERE OrderNo=:new.ORDERNO;
		select ProductNo into proNo from lwn_Procurement_detial where OrderNo=:new.ORDERNO;
		update lwn_stock set qty=qty+proCount where productno=proNo;
	end;
/

